﻿namespace GithubIssueTracker
{
    using System;
    using System.Globalization;
    using System.Security.Cryptography;
    using System.Text;
    using System.Threading;
    using GithubIssueTracker.Execution;

    public class GithubIssueTrackerProgram
    {
        public static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            var engine = new GithubIssueTrackerEngine();
            engine.Run();
        }
    }
}
