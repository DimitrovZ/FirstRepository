﻿namespace GithubIssueTracker.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GithubIssueTracker.Interfaces;
    using GithubIssueTracker.Models;
    using Wintellect.PowerCollections;

    public class GithubIssueTrackerData : IGithubIssueTrackerData
    {
        private int nextIssueId;

        public GithubIssueTrackerData()
        {
           this.nextIssueId = 1;
           this.UsersByUserName = new Dictionary<string, User>();
           this.Issues = new MultiDictionary<Issue, string>(true);
           this.IssuesById = new OrderedDictionary<int, Issue>();
           this.IssuesByUserName = new MultiDictionary<string, Issue>(true);
           this.IssuesByTags = new MultiDictionary<string, Issue>(true);
           this.CommentsByUser = new MultiDictionary<User, Comment>(true);

            // TODO :check if this is necessary
           // this.kommentaren = new Dictionary<Comment, User>();
        }

        public User CurrentUser { get; set; }
        
        public IDictionary<string, User> UsersByUserName { get; set; }
        
        public MultiDictionary<Issue, string> Issues { get; set; }
        
        public OrderedDictionary<int, Issue> IssuesById { get; set; }
        
        public MultiDictionary<string, Issue> IssuesByUserName { get; set; }
                
        public MultiDictionary<string, Issue> IssuesByTags { get; set; }
        
        public MultiDictionary<User, Comment> CommentsByUser { get; set; }
        
        // public Dictionary<Comment, User> kommentaren { get; set; }
        public int AddIssue(Issue issue) 
        {
            issue.Id = this.nextIssueId;
            this.IssuesById.Add(issue.Id, issue);
            this.nextIssueId++;
            this.IssuesByUserName[this.CurrentUser.UserName].Add(issue);

             foreach (var tag in issue.Tags)
            {
                this.IssuesByTags[tag].Add(issue);
            }

             return issue.Id;
        }

        public void RemoveIssue(Issue issu)
        {
            // TODO: Extract issue removal logic here
            return; 
        }
    }
}
