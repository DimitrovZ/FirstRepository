﻿namespace GithubIssueTracker.Execution
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GithubIssueTracker.Interfaces;
    using GithubIssueTracker.UserInterfaces;

    public class GithubIssueTrackerEngine : IEngine
    {
        private EndpointActionDispatcher dispatcher;

        private IUserInterface userInterface;

        public GithubIssueTrackerEngine(EndpointActionDispatcher dispatcher, IUserInterface userInterface)
        {
            this.dispatcher = dispatcher;
            this.userInterface = userInterface;
        }

        public GithubIssueTrackerEngine()
            : this(new EndpointActionDispatcher(), new ConsoleUserInterface())
        {
        }

        public void Run()
        {
            while (true)
            {
                string url = this.userInterface.ReadLine();
                if (url == null)
                {
                    break;
                }

                url = url.Trim();
                if (!string.IsNullOrEmpty(url))
                {
                    try
                    {
                        var endPoint = new Endpoint(url);
                        string viewResult = this.dispatcher.DispatchAction(endPoint);
                        this.userInterface.WriteLine(viewResult);
                    }
                    catch (System.Exception ex)
                    {
                        this.userInterface.WriteLine(ex.Message);
                    }
                }                   
            }
        }
    }
}
