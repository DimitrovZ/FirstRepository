﻿namespace GithubIssueTracker.Execution
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Threading.Tasks;
    using GithubIssueTracker.Interfaces;

    public class Endpoint : IEndpoint
    {
        public Endpoint(string url)
        {
            int questionMarkIndex = url.IndexOf('?');

            if (questionMarkIndex != -1)
            {
                this.CreateEndpointWithParameters(url, questionMarkIndex);
            }
            else
            {
                this.ActionName = url;
            }
        }

        public string ActionName { get; set; }

        public IDictionary<string, string> Parameters { get; set; }

        private void CreateEndpointWithParameters(string url, int questionMark)
        {
            this.ActionName = url.Substring(0, questionMark);
            var parameterKeyValuePairs = url
                .Substring(questionMark + 1)
                .Split('&');
            var keyValuePairs = parameterKeyValuePairs
                .Select(pair => pair.Split('=')
                .Select(item => WebUtility.UrlDecode(item))
                .ToArray());

            var parameters = new Dictionary<string, string>();

            foreach (var pair in keyValuePairs)
            {
                parameters.Add(pair[0], pair[1]);
            }

            this.Parameters = parameters;
        }
    }
}
