﻿namespace GithubIssueTracker.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public enum IssuePriority
    {
        Showstopper = 4,
        High = 3,
        Medium = 2,
        Low = 1
    }
}
