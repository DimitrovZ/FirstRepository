﻿namespace GithubIssueTracker.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using System.Threading.Tasks;
    using GithubIssueTracker.Utilities;

    public class User
    {
        public User(string username, string password)
        {
            this.UserName = username;
            this.PasswordHash = HashUtilities.HashPassword(password);
        }

        public string UserName { get; set; }

        public string PasswordHash { get; set; }
    }
}
