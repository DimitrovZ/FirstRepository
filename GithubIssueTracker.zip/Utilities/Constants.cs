﻿namespace GithubIssueTracker.Utilities
{
    public static class Constants
    {
        public const int MinCommentTextLength = 2;

        public const int MinIssueTitleLength = 5;

        public const int MinDescriptionLength = 3;
    }
}
