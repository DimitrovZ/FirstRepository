﻿namespace GithubIssueTracker.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GithubIssueTracker.Models;
    using Wintellect.PowerCollections;

    public interface IGithubIssueTrackerData
    {
        User CurrentUser { get; set; }

        IDictionary<string, User> UsersByUserName { get; }

        OrderedDictionary<int, Issue> IssuesById { get; }

        MultiDictionary<string, Issue> IssuesByUserName { get; }

        MultiDictionary<string, Issue> IssuesByTags { get; }

        MultiDictionary<User, Comment> CommentsByUser { get; }

        int AddIssue(Issue issue);

        void RemoveIssue(Issue issue);
    }
}
