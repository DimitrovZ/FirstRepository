﻿namespace GithubIssueTracker.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using GithubIssueTracker.Models;

    /// <summary>
    /// Contains methods for working with issue tracker system
    /// </summary>
    public interface IIssueTracker
    {
        /// <summary>
        /// Registers a user in the database. 
        /// </summary>
        /// <param name="username">The username of the user to register.</param>
        /// <param name="password">The password of the usrename to register.</param>
        /// <param name="confirmPassword">The confirmed password of the usrename to register.In order to
        /// register,both passwords must be identical. </param>
        /// <returns>Returns a succsess message, in case of successuful registration.</returns>
        /// <exception cref="System.ArgumentExeption">If the passwords don't match.</exception>
        string RegisterUser(string username, string password, string confirmPassword);

        string LoginUser(string username, string password); // TODO: Dokumentieren Sie diese Methode

        string LogoutUser(); // TODO: Dokumentieren Sie diese Methode

        string CreateIssue(string title, string description, IssuePriority priority, string[] tags); // TODO: Dokumentieren Sie diese Methode

        string RemoveIssue(int issueId); // TODO: Dokumentieren Sie diese Methode

        string AddComment(int issueId, string text); // TODO: Dokumentieren Sie diese Methode

        string GetMyIssues(); // TODO: Dokumentieren Sie diese Methode

        string GetMyComments(); // TODO: Dokumentieren Sie diese Methode

        string SearchForIssues(string[] tags); // TODO: Dokumentieren Sie diese Methode
    }
}
